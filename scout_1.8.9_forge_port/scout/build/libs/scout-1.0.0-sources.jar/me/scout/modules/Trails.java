package me.scout.modules;

import me.scout.Scout;
import me.scout.render.TargetHudRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;
import java.awt.Color;
import java.util.*;

public class Trails {
    private static final Minecraft mc = Minecraft.func_71410_x();
    private static final Map<Integer, List<TrailSegment>> trailMap = new HashMap<>();

    public static void onTick() {
        if (!Scout.config.trailsEnabled) { trailMap.clear(); return; }
        if (mc.field_71441_e == null) return;
        int lifetime = Scout.config.trailsLength;
        for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
            Vec3 prev = new Vec3(player.field_70169_q, player.field_70167_r, player.field_70166_s);
            Vec3 curr = new Vec3(player.field_70165_t, player.field_70163_u, player.field_70161_v);
            if (prev.func_72438_d(curr) > 0.001f)
                getTrails(player.func_145782_y()).add(new TrailSegment(prev, curr, lifetime));
            getTrails(player.func_145782_y()).removeIf(TrailSegment::update);
        }
        Set<Integer> alive = new HashSet<>();
        for (EntityPlayer p : mc.field_71441_e.field_73010_i) alive.add(p.func_145782_y());
        trailMap.keySet().retainAll(alive);
    }

    @SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
        if (!Scout.config.trailsEnabled) return;
        if (mc.field_71441_e == null || mc.field_71439_g == null) return;
        float pt = event.partialTicks;
        double cx = mc.func_175598_ae().field_78730_l;
        double cy = mc.func_175598_ae().field_78731_m;
        double cz = mc.func_175598_ae().field_78728_n;
        GlStateManager.func_179129_p();
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a(false);
        Tessellator tess = Tessellator.func_178181_a();
        WorldRenderer wr = tess.func_178180_c();
        wr.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181706_f);
        for (Map.Entry<Integer, List<TrailSegment>> entry : trailMap.entrySet()) {
            Entity entity = mc.field_71441_e.func_73045_a(entry.getKey());
            if (entity == null) continue;
            if (entity == mc.field_71439_g && mc.field_71474_y.field_74320_O == 0 && !Scout.config.trailsFirstPerson) continue;
            if (!mc.field_71439_g.func_70685_l(entity)) continue;
            List<TrailSegment> segs = entry.getValue();
            if (segs.size() < 2) continue;
            float height = entity.field_70131_O * (Scout.config.trailsHeight / 100f);
            for (int i = 0; i < segs.size() - 1; i++) {
                TrailSegment cur = segs.get(i), next = segs.get(i + 1);
                Vec3 cp = cur.interpolate(pt, cx, cy, cz);
                Vec3 np = next.interpolate(pt, cx, cy, cz);
                float ca = (float)(cur.animation(pt) * 255);
                float na = (float)(next.animation(pt) * 255);
                Color cc = getAnimatedColor(cur.getProgress(pt), 1 - cur.getProgress(pt));
                Color nc = getAnimatedColor(next.getProgress(pt), 1 - next.getProgress(pt));
                int cbA, cmA, ctA, nbA, nmA, ntA;
                Style style = Scout.config.trailsStyle;
                if (style == Style.FADED) {
                    cbA=(int)(fadedAlpha(0,height)*ca/255f); cmA=(int)(fadedAlpha(height/2f,height)*ca/255f); ctA=Scout.config.trailsRenderHalf?0:(int)(fadedAlpha(height,height)*ca/255f);
                    nbA=(int)(fadedAlpha(0,height)*na/255f); nmA=(int)(fadedAlpha(height/2f,height)*na/255f); ntA=Scout.config.trailsRenderHalf?0:(int)(fadedAlpha(height,height)*na/255f);
                } else if (style == Style.FADED_INVERT) {
                    cbA=(int)(fadedInvert(0,height)*ca/255f); cmA=(int)(fadedInvert(height/2f,height)*ca/255f); ctA=Scout.config.trailsRenderHalf?0:(int)(fadedInvert(height,height)*ca/255f);
                    nbA=(int)(fadedInvert(0,height)*na/255f); nmA=(int)(fadedInvert(height/2f,height)*na/255f); ntA=Scout.config.trailsRenderHalf?0:(int)(fadedInvert(height,height)*na/255f);
                } else {
                    cbA=cmA=(int)ca; ctA=Scout.config.trailsRenderHalf?0:(int)ca;
                    nbA=nmA=(int)na; ntA=Scout.config.trailsRenderHalf?0:(int)na;
                }
                float x1=(float)cp.field_72450_a, y1=(float)cp.field_72448_b, z1=(float)cp.field_72449_c;
                float x2=(float)np.field_72450_a, y2=(float)np.field_72448_b, z2=(float)np.field_72449_c;
                wr.func_181662_b(x1,y1,z1).func_181669_b(cc.getRed(),cc.getGreen(),cc.getBlue(),cbA).func_181675_d();
                wr.func_181662_b(x2,y2,z2).func_181669_b(nc.getRed(),nc.getGreen(),nc.getBlue(),nbA).func_181675_d();
                wr.func_181662_b(x2,y2+height/2f,z2).func_181669_b(nc.getRed(),nc.getGreen(),nc.getBlue(),nmA).func_181675_d();
                wr.func_181662_b(x1,y1+height/2f,z1).func_181669_b(cc.getRed(),cc.getGreen(),cc.getBlue(),cmA).func_181675_d();
                if (!Scout.config.trailsRenderHalf) {
                    wr.func_181662_b(x1,y1+height/2f,z1).func_181669_b(cc.getRed(),cc.getGreen(),cc.getBlue(),cmA).func_181675_d();
                    wr.func_181662_b(x2,y2+height/2f,z2).func_181669_b(nc.getRed(),nc.getGreen(),nc.getBlue(),nmA).func_181675_d();
                    wr.func_181662_b(x2,y2+height,z2).func_181669_b(nc.getRed(),nc.getGreen(),nc.getBlue(),ntA).func_181675_d();
                    wr.func_181662_b(x1,y1+height,z1).func_181669_b(cc.getRed(),cc.getGreen(),cc.getBlue(),ctA).func_181675_d();
                }
            }
        }
        tess.func_78381_a();
        GlStateManager.func_179132_a(true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179089_o();
    }

    private static List<TrailSegment> getTrails(int id) { return trailMap.computeIfAbsent(id, k -> new ArrayList<>()); }
    private static int fadedAlpha(float y, float h) { float r=y/h; return r<=0.5f?(int)((1f-r/0.5f)*255):(int)(((r-0.5f)/0.5f)*255); }
    private static int fadedInvert(float y, float h) { float r=y/h; int af=(int)(255*(Scout.config.trailsAlphaFactor/100f)); return r<=0.5f?(int)(af+(r/0.5f)*(255-af)):(int)(255-((r-0.5f)/0.5f)*(255-af)); }
    public static Color getAnimatedColor(float x, float y) {
        Color c1=TargetHudRenderer.topLeft, c2=TargetHudRenderer.topRight, c3=TargetHudRenderer.bottomRight, c4=TargetHudRenderer.bottomLeft;
        return lerpColor(lerpColor(c1,c2,x), lerpColor(c4,c3,x), y);
    }
    public static Color lerpColor(Color a, Color b, float t) { return new Color((int)(a.getRed()+(b.getRed()-a.getRed())*t),(int)(a.getGreen()+(b.getGreen()-a.getGreen())*t),(int)(a.getBlue()+(b.getBlue()-a.getBlue())*t)); }

    public static class TrailSegment {
        private final Vec3 from, to; private int ticks, prevTicks; private final int maxLifetime;
        public TrailSegment(Vec3 f, Vec3 t, int l) { from=f; to=t; ticks=l; maxLifetime=l; }
        public Vec3 interpolate(float pt, double cx, double cy, double cz) { return new Vec3(from.field_72450_a+(to.field_72450_a-from.field_72450_a)*pt-cx, from.field_72448_b+(to.field_72448_b-from.field_72448_b)*pt-cy, from.field_72449_c+(to.field_72449_c-from.field_72449_c)*pt-cz); }
        public double animation(float pt) { float age=maxLifetime-(prevTicks+(ticks-prevTicks)*pt); return Math.max(0,1-age/maxLifetime); }
        public boolean update() { prevTicks=ticks; return ticks--<=0; }
        public float getProgress(float pt) { return (maxLifetime-(prevTicks+(ticks-prevTicks)*pt))/(float)maxLifetime; }
    }
    public enum Style { FADED, SOLID, FADED_INVERT }
}