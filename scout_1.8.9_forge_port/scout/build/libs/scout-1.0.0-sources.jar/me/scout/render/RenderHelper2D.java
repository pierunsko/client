package me.scout.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

import java.awt.Color;

/**
 * RenderHelper2D — 1.8.9 Forge equivalent of SoupAPI's Render2D.
 *
 * Key API differences from 1.21.4:
 *  - No MatrixStack  → use GL11 push/pop + translate/scale
 *  - No DrawContext  → draw directly via Tessellator
 *  - Rounded corners drawn by triangle fan with hand-rolled arc segments
 *  - Blurred shadow is approximated by layered semi-transparent quads (no BufferedImage needed)
 */
public class RenderHelper2D {

    private static final Minecraft mc = Minecraft.func_71410_x();

    // ─── Basic rect ───────────────────────────────────────────────────────────

    public static void drawRect(float x, float y, float w, float h, Color color) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179090_x();
        GlStateManager.func_179131_c(color.getRed() / 255f, color.getGreen() / 255f,
                color.getBlue() / 255f, color.getAlpha() / 255f);
        Tessellator tess = Tessellator.func_178181_a();
        WorldRenderer wr = tess.func_178180_c();
        wr.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181705_e);
        wr.func_181662_b(x,     y + h, 0).func_181675_d();
        wr.func_181662_b(x + w, y + h, 0).func_181675_d();
        wr.func_181662_b(x + w, y,     0).func_181675_d();
        wr.func_181662_b(x,     y,     0).func_181675_d();
        tess.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    // ─── Gradient rect (4 corner colors) ─────────────────────────────────────

    public static void drawGradientRect(float x, float y, float w, float h,
                                        Color tl, Color tr, Color br, Color bl) {
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179090_x();
        GlStateManager.func_179103_j(GL11.GL_SMOOTH);
        Tessellator tess = Tessellator.func_178181_a();
        WorldRenderer wr = tess.func_178180_c();
        wr.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181706_f);
        wr.func_181662_b(x,     y + h, 0).func_181669_b(bl.getRed(), bl.getGreen(), bl.getBlue(), bl.getAlpha()).func_181675_d();
        wr.func_181662_b(x + w, y + h, 0).func_181669_b(br.getRed(), br.getGreen(), br.getBlue(), br.getAlpha()).func_181675_d();
        wr.func_181662_b(x + w, y,     0).func_181669_b(tr.getRed(), tr.getGreen(), tr.getBlue(), tr.getAlpha()).func_181675_d();
        wr.func_181662_b(x,     y,     0).func_181669_b(tl.getRed(), tl.getGreen(), tl.getBlue(), tl.getAlpha()).func_181675_d();
        tess.func_78381_a();
        GlStateManager.func_179103_j(GL11.GL_FLAT);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    // ─── Rounded rect (triangle fan) ─────────────────────────────────────────

    public static void drawRoundedRect(float x, float y, float w, float h,
                                       float radius, Color color) {
        drawRoundedRectGradient(x, y, w, h, radius, color, color, color, color);
    }

    /**
     * Draws a rounded rectangle with per-corner gradient.
     * Corner order: topLeft, topRight, bottomRight, bottomLeft.
     */
    public static void drawRoundedRectGradient(float x, float y, float w, float h,
                                               float radius, Color tl, Color tr, Color br, Color bl) {
        radius = Math.min(radius, Math.min(w, h) / 2f);
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179090_x();
        GlStateManager.func_179103_j(GL11.GL_SMOOTH);

        Tessellator tess = Tessellator.func_178181_a();
        WorldRenderer wr = tess.func_178180_c();
        wr.func_181668_a(GL11.GL_TRIANGLE_FAN, DefaultVertexFormats.field_181706_f);

        // Center vertex (average color)
        Color center = avgColor(tl, tr, br, bl);
        wr.func_181662_b(x + w / 2f, y + h / 2f, 0)
          .func_181669_b(center.getRed(), center.getGreen(), center.getBlue(), center.getAlpha())
          .func_181675_d();

        int segments = 8; // per corner
        // BL corner
        addArc(wr, x + radius,         y + h - radius, radius, 180, 270, segments, bl);
        // BR corner
        addArc(wr, x + w - radius,     y + h - radius, radius, 270, 360, segments, br);
        // TR corner
        addArc(wr, x + w - radius,     y + radius,     radius,   0,  90, segments, tr);
        // TL corner
        addArc(wr, x + radius,         y + radius,     radius,  90, 180, segments, tl);

        // close fan back to BL start
        double rad = Math.toRadians(180);
        wr.func_181662_b((float)(x + radius + Math.cos(rad) * radius),
               (float)(y + h - radius + Math.sin(rad) * radius), 0)
          .func_181669_b(bl.getRed(), bl.getGreen(), bl.getBlue(), bl.getAlpha())
          .func_181675_d();

        tess.func_78381_a();

        GlStateManager.func_179103_j(GL11.GL_FLAT);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    private static void addArc(WorldRenderer wr, float cx, float cy, float r,
                                int startDeg, int endDeg, int segments, Color c) {
        for (int i = 0; i <= segments; i++) {
            double angle = Math.toRadians(startDeg + (endDeg - startDeg) * i / (double)segments);
            wr.func_181662_b(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r, 0)
              .func_181669_b(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha())
              .func_181675_d();
        }
    }

    // ─── HP bar ──────────────────────────────────────────────────────────────

    /**
     * Background trough (dark, rounded) + filled bar (gradient, rounded).
     * Matches SoupAPI pattern: drawGradientRound + renderRoundedGradientRect.
     */
    public static void drawHealthBar(float x, float y, float totalW, float filledW,
                                     float h, float radius,
                                     Color bgColor,
                                     Color barLeft, Color barRight) {
        // Background
        drawRoundedRect(x, y, totalW, h, radius, bgColor);
        // Filled portion
        if (filledW > 0) {
            drawRoundedRectGradient(x, y, filledW, h, radius, barLeft, barRight, barRight, barLeft);
        }
    }

    // ─── Glow / blurred shadow (layered quads approximation) ─────────────────

    /**
     * Approximate a coloured bloom shadow by drawing several expanding, fading rects.
     * Matches the visual intent of SoupAPI's drawGradientBlurredShadow1.
     */
    public static void drawGlowShadow(float x, float y, float w, float h,
                                      int layers, Color color) {
        if (layers <= 0) return;
        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        GlStateManager.func_179090_x();
        GlStateManager.func_179103_j(GL11.GL_SMOOTH);

        for (int i = layers; i >= 1; i--) {
            float expand = i * 1.2f;
            float alpha  = (color.getAlpha() / 255f) * (1f - i / (float)(layers + 1)) * 0.35f;
            Color c = new Color(color.getRed() / 255f, color.getGreen() / 255f,
                                color.getBlue() / 255f, alpha);
            drawRoundedRect(x - expand, y - expand, w + expand * 2, h + expand * 2, 4, c);
        }

        GlStateManager.func_179103_j(GL11.GL_FLAT);
        GlStateManager.func_179098_w();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179084_k();
    }

    // ─── Player head rendering ────────────────────────────────────────────────

    /**
     * Renders the player's head (face layer + hat layer) inside a rounded clip region.
     * In 1.8.9 we use the standard skin texture with UV offsets.
     */
    public static void drawPlayerHead(net.minecraft.client.network.NetworkPlayerInfo info,
                                      float x, float y, float size, float radius,
                                      float hurtFlash) {
        if (info == null) return;
        net.minecraft.util.ResourceLocation skin = info.func_178837_g();

        GlStateManager.func_179147_l();
        GlStateManager.func_179112_b(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GlStateManager.func_179098_w();
        GlStateManager.func_179131_c(1f, 1f - hurtFlash * 0.5f, 1f - hurtFlash * 0.5f, 1f);

        mc.func_110434_K().func_110577_a(skin);

        // Face layer  (u=8,v=8 in 64x64 atlas → uv = 8/64 = 0.125)
        drawTexturedRect(x, y, size, size, 8, 8, 8, 8, 64, 64);
        // Hat layer   (u=40,v=8)
        drawTexturedRect(x, y, size, size, 40, 8, 8, 8, 64, 64);

        GlStateManager.func_179131_c(1f, 1f, 1f, 1f);
        GlStateManager.func_179084_k();
    }

    // ─── Texture quad ─────────────────────────────────────────────────────────

    public static void drawTexturedRect(float x, float y, float w, float h,
                                        float u, float v,
                                        float regionW, float regionH,
                                        float texW, float texH) {
        float u0 = u / texW,        v0 = v / texH;
        float u1 = (u + regionW) / texW, v1 = (v + regionH) / texH;
        Tessellator tess = Tessellator.func_178181_a();
        WorldRenderer wr = tess.func_178180_c();
        wr.func_181668_a(GL11.GL_QUADS, DefaultVertexFormats.field_181707_g);
        wr.func_181662_b(x,     y + h, 0).func_181673_a(u0, v1).func_181675_d();
        wr.func_181662_b(x + w, y + h, 0).func_181673_a(u1, v1).func_181675_d();
        wr.func_181662_b(x + w, y,     0).func_181673_a(u1, v0).func_181675_d();
        wr.func_181662_b(x,     y,     0).func_181673_a(u0, v0).func_181675_d();
        tess.func_78381_a();
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    public static Color applyOpacity(Color c, float opacity) {
        opacity = Math.max(0f, Math.min(1f, opacity));
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), (int)(c.getAlpha() * opacity));
    }

    public static Color fromARGB(int argb) { return new Color(argb, true); }

    private static Color avgColor(Color a, Color b, Color c, Color d) {
        return new Color(
            (a.getRed()   + b.getRed()   + c.getRed()   + d.getRed())   / 4,
            (a.getGreen() + b.getGreen() + c.getGreen() + d.getGreen()) / 4,
            (a.getBlue()  + b.getBlue()  + c.getBlue()  + d.getBlue())  / 4,
            (a.getAlpha() + b.getAlpha() + c.getAlpha() + d.getAlpha()) / 4
        );
    }

    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    public static Color interpolateColor(Color start, Color end, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
            (int)(start.getRed()   + (end.getRed()   - start.getRed())   * t),
            (int)(start.getGreen() + (end.getGreen() - start.getGreen()) * t),
            (int)(start.getBlue()  + (end.getBlue()  - start.getBlue())  * t),
            (int)(start.getAlpha() + (end.getAlpha() - start.getAlpha()) * t)
        );
    }
}
